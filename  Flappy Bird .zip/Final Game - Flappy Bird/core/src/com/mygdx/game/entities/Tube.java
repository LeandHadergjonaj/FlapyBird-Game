package com.mygdx.game.entities;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.Gdx;

import java.util.Random;

public class Tube {
    public static final int TUBE_WIDTH = 52;
    private static final int TUBE_GAP = 150; // Gap between top and bottom tubes
    private static final int TUBE_SPEED = -200;
    private static final int MIN_TUBE_HEIGHT = 50;
    private static final int FLUCTUATION = 150;

    private Vector2 posTopTube, posBottomTube;
    private Rectangle boundsTop, boundsBottom;
    private Random rand;
    private boolean passed;

    public Tube(float x) {
        rand = new Random();
        reposition(x);
        passed = false;
    }

    public void update(float dt) {
        posTopTube.add(TUBE_SPEED * dt, 0);
        posBottomTube.add(TUBE_SPEED * dt, 0);
        boundsTop.setPosition(posTopTube.x, posTopTube.y);
        boundsBottom.setPosition(posBottomTube.x, posBottomTube.y);
    }

    public void reposition(float x) {
        int screenHeight = Gdx.graphics.getHeight();

        // Random height for bottom tube
        int bottomTubeHeight = rand.nextInt(FLUCTUATION) + MIN_TUBE_HEIGHT;
        // Height for top tube to ensure gap
        int topTubeHeight = screenHeight - bottomTubeHeight - TUBE_GAP;

        // Ensure the bottom tube starts from the bottom of the screen
        posBottomTube = new Vector2(x, 0);

        // Ensure the top tube starts from the top of the screen
        posTopTube = new Vector2(x, screenHeight - topTubeHeight);

        boundsTop = new Rectangle(posTopTube.x, posTopTube.y, TUBE_WIDTH, topTubeHeight);
        boundsBottom = new Rectangle(posBottomTube.x, posBottomTube.y, TUBE_WIDTH, bottomTubeHeight);

        passed = false; // Reset passed flag when repositioning
    }

    public boolean collides(Rectangle player) {
        return player.overlaps(boundsTop) || player.overlaps(boundsBottom);
    }

    public boolean isOffScreen(float screenX) {
        return posTopTube.x + TUBE_WIDTH < screenX;
    }

    public Vector2 getPosTopTube() {
        return posTopTube;
    }

    public Vector2 getPosBottomTube() {
        return posBottomTube;
    }

    public void renderCollisionBoxes(ShapeRenderer shapeRenderer) {
        shapeRenderer.rect(boundsTop.x, boundsTop.y, boundsTop.width, boundsTop.height);
        shapeRenderer.rect(boundsBottom.x, boundsBottom.y, boundsBottom.width, boundsBottom.height);
    }

    public void dispose() {
        // No resources to dispose in this version
    }

    public boolean isPassed() {
        return passed;
    }

    public void setPassed(boolean passed) {
        this.passed = passed;
    }
}
