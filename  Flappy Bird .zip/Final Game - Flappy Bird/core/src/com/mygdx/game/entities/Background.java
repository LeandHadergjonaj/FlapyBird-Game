package com.mygdx.game.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Background {
    private Texture background;

    public Background() {
        background = new Texture("background.png");
    }

    public void render(SpriteBatch batch, float screenWidth, float screenHeight) {
        batch.draw(background, 0, 0, screenWidth, screenHeight);
    }

    public void dispose() {
        background.dispose();
    }
}
