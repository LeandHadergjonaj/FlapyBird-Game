package com.mygdx.game.entities;

public class Score {
    protected int score;

    public Score() {
        score = 0;
    }

    public void increment() {
        score++;
    }

    public int getScore() {
        return score;
    }
}
