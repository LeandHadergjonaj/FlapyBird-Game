package com.mygdx.game.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

public class Bird {
    private static final float GRAVITY = -1000; // Fast gravity for a quick fall
    private static final float JUMP_VELOCITY = 400; // Smaller jump velocity for smaller jumps
    private static final float BIRD_WIDTH = 80;
    private static final float BIRD_HEIGHT = 65;
    private Vector2 position;
    private Vector2 velocity;
    private Texture birdTexture;

    public Bird(int x, int y) {
        position = new Vector2(x, y);
        velocity = new Vector2(0, 0);
        birdTexture = new Texture(Gdx.files.internal("bird.png"));
    }

    public void update(float dt) {
        // Apply gravity
        if (position.y > 0 || velocity.y > 0) {
            velocity.add(0, GRAVITY * dt);
        } else {
            position.y = 0;
            velocity.y = 0;
        }

        // Update position
        position.add(0, velocity.y * dt);


        System.out.println("Update - Position: " + position.y + " Velocity: " + velocity.y);
    }

    public void jump() {
        velocity.y = JUMP_VELOCITY;

        System.out.println("Jump! Velocity: " + velocity.y);
    }

    public Vector2 getPosition() {
        return position;
    }

    public Texture getTexture() {
        return birdTexture;
    }

    public void render(SpriteBatch batch) {
        batch.draw(birdTexture, position.x, position.y, BIRD_WIDTH, BIRD_HEIGHT);
    }

    public void dispose() {
        birdTexture.dispose();
    }
}
