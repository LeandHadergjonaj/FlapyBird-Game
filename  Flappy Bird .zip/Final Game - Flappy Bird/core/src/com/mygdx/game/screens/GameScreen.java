package com.mygdx.game.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.MyGdxGame;
import com.mygdx.game.entities.Background;
import com.mygdx.game.entities.Bird;
import com.mygdx.game.entities.Tube;

import java.io.BufferedReader;
import java.io.IOException;

public class GameScreen implements Screen {
    private static final int TUBE_SPACING = 200;
    private static final int TUBE_COUNT = 4;
    private static final float BIRD_START_X = 50;
    private static final float BIRD_START_Y = 300;
    private static final String SCORE_FILE = "scores.txt";

    private MyGdxGame game;
    private Bird bird;
    private Tube[] tubes;
    private Background background;
    private SpriteBatch batch;
    private ShapeRenderer shapeRenderer;
    private Rectangle birdBounds;
    private OrthographicCamera camera;
    private Viewport viewport;
    private boolean gameOver;
    private boolean gameStarted;
    private int score;
    private int bestScore;
    private BitmapFont font;


    private Sound pointSound;
    private Sound hitSound;
    private Sound dieSound;

    public GameScreen(MyGdxGame game) {
        this.game = game;
        bird = new Bird((int) BIRD_START_X, (int) BIRD_START_Y);
        background = new Background();
        batch = new SpriteBatch();
        shapeRenderer = new ShapeRenderer();
        birdBounds = new Rectangle(bird.getPosition().x, bird.getPosition().y, 50, 35);

        camera = new OrthographicCamera();
        viewport = new FitViewport(800, 480, camera);
        camera.position.set(camera.viewportWidth / 2, camera.viewportHeight / 2, 0);
        camera.update();

        tubes = new Tube[TUBE_COUNT];
        for (int i = 0; i < TUBE_COUNT; i++) {
            tubes[i] = new Tube(800 + i * (TUBE_SPACING + Tube.TUBE_WIDTH));
        }

        gameOver = false;
        gameStarted = false;
        score = 0;
        bestScore = loadBestScore();
        font = new BitmapFont();

        // Load sound effects
        pointSound = Gdx.audio.newSound(Gdx.files.internal("point.wav"));
        hitSound = Gdx.audio.newSound(Gdx.files.internal("hit.wav"));
        dieSound = Gdx.audio.newSound(Gdx.files.internal("die.wav"));
    }

    @Override
    public void show() {
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        camera.update();
        batch.setProjectionMatrix(camera.combined);

        if (!gameOver) {
            update(delta);
        } else {
            handleGameOverInput();
        }

        batch.begin();
        background.render(batch, camera.viewportWidth, camera.viewportHeight);
        bird.render(batch);
        font.draw(batch, "Score: " + score, 10, viewport.getWorldHeight() - 10); // Display score
        if (gameOver) {
            font.draw(batch, "Game Over!", camera.viewportWidth / 2 - 40, camera.viewportHeight / 2);
            font.draw(batch, "Last Score: " + score, camera.viewportWidth / 2 - 40, camera.viewportHeight / 2 - 20);
            font.draw(batch, "Best Score: " + bestScore, camera.viewportWidth / 2 - 40, camera.viewportHeight / 2 - 40);
            font.draw(batch, "Press R to Restart or ESC to Quit", camera.viewportWidth / 2 - 80, camera.viewportHeight / 2 - 60);
        }
        batch.end();

        shapeRenderer.setProjectionMatrix(camera.combined);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(0, 1, 0, 1); // Green color for filled tubes
        for (Tube tube : tubes) {
            tube.renderCollisionBoxes(shapeRenderer);
        }
        shapeRenderer.end();
    }

    private void update(float delta) {
        handleInput();

        if (gameStarted) {
            bird.update(delta);
            birdBounds.setPosition(bird.getPosition().x, bird.getPosition().y);

            if (bird.getPosition().y <= 0 || bird.getPosition().y >= viewport.getWorldHeight() - birdBounds.height) {
                gameOver = true;
                saveScore(score);
                dieSound.play(); // Play die sound when bird hits the ground or top
            }

            for (Tube tube : tubes) {
                tube.update(delta);
                if (tube.collides(birdBounds)) {
                    gameOver = true;
                    saveScore(score); // Save score when game is over
                    hitSound.play(); // Play hit sound when bird hits a tube
                    dieSound.play(); // Play die sound when bird hits a tube
                    break;
                }
                if (tube.isOffScreen(camera.position.x - camera.viewportWidth / 2)) {
                    tube.reposition(tube.getPosTopTube().x + ((Tube.TUBE_WIDTH + TUBE_SPACING) * TUBE_COUNT));
                }
                if (tube.getPosBottomTube().x + Tube.TUBE_WIDTH < bird.getPosition().x && !tube.isPassed()) {
                    score++;
                    pointSound.play(); // Play point sound when bird passes a tube
                    tube.setPassed(true);
                }
            }
        }
    }

    private void handleInput() {
        if (!gameOver && Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            if (!gameStarted) {
                gameStarted = true;
            }
            bird.jump();
        }
    }

    private void handleGameOverInput() {
        if (Gdx.input.isKeyJustPressed(Input.Keys.R)) {
            restartGame();
        } else if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
            Gdx.app.exit();
        }
    }

    private void restartGame() {
        game.setScreen(new GameScreen(game));
    }

    private void saveScore(int score) {
        try {
            FileHandle file = Gdx.files.local(SCORE_FILE);
            file.writeString(String.valueOf(score) + "\n", true);
            if (score > bestScore) {
                bestScore = score;
                file.writeString("best:" + bestScore + "\n", true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private int loadBestScore() {
        int bestScore = 0;
        try {
            FileHandle file = Gdx.files.local(SCORE_FILE);
            if (file.exists()) {
                BufferedReader reader = new BufferedReader(file.reader());
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith("best:")) {
                        bestScore = Integer.parseInt(line.split(":")[1]);
                    }
                }
                reader.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bestScore;
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
        camera.position.set(camera.viewportWidth / 2, camera.viewportHeight / 2, 0);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
        bird.dispose();
        background.dispose();
        for (Tube tube : tubes) {
            tube.dispose();
        }
        batch.dispose();
        shapeRenderer.dispose();
        font.dispose();
        pointSound.dispose();
        hitSound.dispose();
        dieSound.dispose();
    }
}
